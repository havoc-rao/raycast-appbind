import { Action, ActionPanel, Detail, Form, Icon, Toast, closeMainWindow, environment, getPreferenceValues, showToast, useNavigation } from "@raycast/api";
import { useEffect, useRef, useState } from "react";
import { getFrontmostApplication } from "@raycast/api";
import { resolveActiveApplication } from "./active-app";
import { logDebug, logFile, readLogTail } from "./debug-log";
import { Anchor, Binding, Config, anchors, round2 } from "./config";
import { findShortcutConflict, formatShortcut } from "./shortcut";
import { ConfigStore } from "./storage";
import { CaptureData, ShortcutData, Request, callHelper } from "./transport";
export const store = new ConfigStore(environment.supportPath);
export const warning = "Diagnostic only — no click, cursor movement, app activation, or hotkey registration. Raycast may be the frontmost app; APP_MISMATCH is expected in that case. We never hide Raycast and guess a previous window. A successful dry-run does not attest click safety.";
export const message = (e: unknown) => e instanceof Error ? e.message : String(e);
export async function failure(e: unknown) { await showToast({ style: Toast.Style.Failure, title: "AppBind refused operation", message: message(e) }); }
export function DebugLog() {
  const [text, setText] = useState("读取中…"); const [file, setFile] = useState("…"); const [loading, setLoading] = useState(true);
  async function reload() { setLoading(true); try { setFile(await logFile()); setText(await readLogTail()); } catch (e) { setText(message(e)); } finally { setLoading(false); } }
  useEffect(() => { void reload(); }, []);
  return <Detail isLoading={loading} markdown={`# AppBind 调试日志\n\n文件位置：\`${file}\`\n\n\`\`\`text\n${text}\n\`\`\``} actions={<ActionPanel><Action title="刷新日志" onAction={reload} /><Action.CopyToClipboard title="复制日志路径" content={file} /></ActionPanel>} />;
}
export function Diagnostic({ request }: { request: Request }) {
  const [text, setText] = useState("Querying helper…"); const [loading, setLoading] = useState(true);
  async function run() {
    setLoading(true);
    try {
      const response = await callHelper(getPreferenceValues<{ helperPath: string }>().helperPath, request);
      setText("```json\n" + JSON.stringify(response, null, 2) + "\n```");
    } catch (e) { setText(message(e)); } finally { setLoading(false); }
  }
  useEffect(() => { void run(); }, []);
  return <Detail isLoading={loading} markdown={`# ${request.command}\n\n${warning}\n\n${text}`} actions={<ActionPanel><Action title="Refresh Diagnostic" onAction={run} /></ActionPanel>} />;
}
interface Values { id: string; name: string; enabled: boolean }
export function BindingForm({ binding, saved }: { binding?: Binding; saved?: (config: Config) => void }) {
  const { pop } = useNavigation(); const [busy, setBusy] = useState(false); const [error, setError] = useState<string>();
  const [bundleId, setBundleId] = useState(binding?.application.bundleId ?? "");
  const [appInfo, setAppInfo] = useState(binding ? "保留已保存的应用；可从操作菜单重新获取。" : "正在获取当前激活应用…");
  const [detecting, setDetecting] = useState(false);
  const [anchor, setAnchor] = useState<Anchor>(binding?.action.anchor ?? "top-left");
  const [x, setX] = useState((binding?.action.offset.x ?? 0).toFixed(2));
  const [y, setY] = useState((binding?.action.offset.y ?? 0).toFixed(2));
  const [capturing, setCapturing] = useState(false);
  const [recording, setRecording] = useState(false);
  const [shortcut, setShortcut] = useState<ShortcutData | undefined>(binding ? { key: binding.trigger.key, modifiers: [...binding.trigger.modifiers] } : undefined);
  const [shortcutError, setShortcutError] = useState<string>();
  const interactiveSession = useRef(false);
  const mounted = useRef(true);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  async function recordShortcut() {
    if (busy || detecting || interactiveSession.current) return;
    interactiveSession.current = true;
    setRecording(true);
    try {
      const helperPath = getPreferenceValues<{ helperPath: string }>().helperPath;
      // Check availability before hiding the form; recording itself needs no AX permission.
      const preflight = await callHelper(helperPath, { protocolVersion: 1, command: "status" });
      if (!preflight.ok) throw new Error(`${preflight.error.code}: ${preflight.error.message}`);
      await closeMainWindow();
      const response = await callHelper(helperPath, { protocolVersion: 1, command: "record-shortcut" });
      if (!mounted.current) return;
      if (!response.ok) {
        if (response.error.code === "USER_CANCELLED") {
          await showToast({ style: Toast.Style.Success, title: "录制已取消，原快捷键未改变" });
          return;
        }
        throw new Error(`${response.error.code}: ${response.error.message}`);
      }
      const candidate = response.data as unknown as ShortcutData;
      const conflict = findShortcutConflict(await store.read(), bundleId, candidate, binding?.id);
      if (!mounted.current) return;
      if (conflict) {
        const text = `${formatShortcut(candidate)} 已用于此 App 的「${conflict.name}」。原快捷键未改变，请重新设置。`;
        setShortcutError(text);
        await showToast({ style: Toast.Style.Failure, title: "快捷键冲突", message: text });
        return;
      }
      setShortcut(candidate);
      setShortcutError(undefined);
      await showToast({ style: Toast.Style.Success, title: "快捷键已确认，请保存规则", message: formatShortcut(candidate) });
    } catch (e) { if (mounted.current) await failure(e); }
    finally { interactiveSession.current = false; if (mounted.current) setRecording(false); }
  }
  const generation = useRef(0);
  async function detectApplication() {
    const request = ++generation.current;
    setDetecting(true);
    try {
      const app = await resolveActiveApplication(getFrontmostApplication);
      await logDebug("detectApp", `resolved ${app.bundleId} name="${app.name}"`);
      if (request !== generation.current) return;
      setBundleId(app.bundleId);
      setAppInfo(`已获取：${app.name} · ${app.bundleId}（仅应用标识，不代表点击窗口已验证）`);
    } catch (e) {
      await logDebug("detectApp", `failure: ${e instanceof Error ? e.message : String(e)}`);
      if (request === generation.current) setAppInfo(message(e));
    } finally { if (request === generation.current) setDetecting(false); }
  }
  useEffect(() => {
    if (!binding) void detectApplication();
    return () => { generation.current++; };
  }, []);
  async function pickPoint() {
    await logDebug("pickPoint", `entered bundleId="${bundleId}" anchor="${anchor}" busy=${busy} detecting=${detecting} capturing=${capturing}`);
    if (busy || detecting || interactiveSession.current) return;
    // The helper never accepts client-provided identity beyond bundleId+anchor and never auto-fills anything; abort on an invalid form value instead of guessing.
    if (bundleId.length > 255 || !/^[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+$(?![\s\S])/.test(bundleId)) {
      await logDebug("pickPoint", "aborted: invalid bundleId in form");
      await failure(new Error("请先在表单中填入或获取有效的 App Bundle ID，再开始取点。"));
      return;
    }
    interactiveSession.current = true;
    setCapturing(true);
    try {
      // Precheck while the panel is still visible: a failing helper must produce a visible error.
      const helperPath = getPreferenceValues<{ helperPath: string }>().helperPath;
      await logDebug("pickPoint", `preflight status helperPath="${helperPath}"`);
      const preflight = await callHelper(helperPath, { protocolVersion: 1, command: "status" });
      await logDebug("pickPoint", `preflight ok=${preflight.ok} trusted=${preflight.ok ? preflight.data.accessibilityTrusted : "n/a"}`);
      if (!preflight.ok || !preflight.data.accessibilityTrusted) {
        await logDebug("pickPoint", "aborted: accessibility not trusted");
        await failure(new Error("PERMISSION_DENIED: Helper 尚无辅助功能权限。请先在 系统设置 → 隐私与安全性 → 辅助功能 中授权 Helper，再重试。"));
        return;
      }
      // The picking overlay must become key, so close the Raycast panel first (closeMainWindow exists in @raycast/api 1.104.5 types).
      await logDebug("pickPoint", "closing main window");
      await closeMainWindow({ clearRootSearch: true });
      await logDebug("pickPoint", `calling capture bundleId="${bundleId}" anchor="${anchor}"`);
      const response = await callHelper(helperPath, { protocolVersion: 1, command: "capture", bundleId, anchor });
      if (!response.ok) {
        await logDebug("pickPoint", `helper failed ${response.error.code}: ${response.error.message}`);
        await failure(new Error(`${response.error.code}: ${response.error.message}`));
        return;
      }
      const d = response.data as unknown as CaptureData; // parseResponse validated the capture success shape for command === "capture"
      await logDebug("pickPoint", `confirmed offset=(${d.offset.x},${d.offset.y}) anchor=${d.anchor} pid=${d.pid}`);
      setAnchor(d.anchor); setX(d.offset.x.toFixed(2)); setY(d.offset.y.toFixed(2));
      setAppInfo(`已取点：${d.bundleId} · pid ${d.pid} · 窗口 frame (${d.frame.x}, ${d.frame.y}) ${d.frame.width}×${d.frame.height} · 用时 ${d.durationMs}ms。仅取出锚点与偏移，未改变应用标识，请手动保存。`);
      await showToast({ style: Toast.Style.Success, title: "偏移已填入，请保存规则" });
    } catch (e) {
      await logDebug("pickPoint", `exception: ${e instanceof Error ? (e.stack ?? e.message) : String(e)}`);
      await failure(e);
    } finally { interactiveSession.current = false; setCapturing(false); }
  }
  async function submit(v: Values) {
    if (busy || interactiveSession.current) return; setBusy(true); setError(undefined);
    try {
      if (!x.trim() || !y.trim() || !/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(x) || !/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(y)) throw new Error("Offsets must be decimal numbers");
      if (!shortcut) {
        setShortcutError("尚未设置快捷键，请点击底部「设置快捷键」。");
        throw new Error("请先设置快捷键");
      }
      const next: Binding = { id: binding?.id ?? v.id, name: v.name, enabled: v.enabled, application: { bundleId }, trigger: { type: "hotkey", key: shortcut.key, modifiers: shortcut.modifiers, scope: "frontmost-app" }, action: { type: "window-relative-click", window: "focused", anchor, offset: { x: round2(Number(x)), y: round2(Number(y)) }, button: "left", restoreCursor: true } };
      const config = await store.update(current => {
        if (binding) {
          const latest = current.bindings.find(b => b.id === binding.id);
          if (JSON.stringify(latest) !== JSON.stringify(binding)) throw new Error("Binding changed or was deleted; reopen before editing");
          return { ...current, bindings: current.bindings.map(b => b.id === binding.id ? next : b) };
        }
        return { ...current, bindings: [...current.bindings, next] };
      });
      await showToast({ style: Toast.Style.Success, title: "Binding saved", message: "Definition only; no hotkey registered" });
      if (saved) { saved(config); pop(); } else { setError("Saved. Use Manage Bindings to edit or diagnose. Change ID to create another binding."); }
    } catch (e) { setError(message(e)); await failure(e); } finally { setBusy(false); }
  }
  return <Form isLoading={busy || detecting || capturing || recording} navigationTitle={binding ? "Edit Binding" : "Create Binding"} actions={<ActionPanel>
      <Action title="设置快捷键" icon={Icon.Keyboard} shortcut={{ modifiers: ["cmd", "shift"], key: "r" }} onAction={recordShortcut} />
      <Action.SubmitForm title="保存规则" shortcut={{ modifiers: ["cmd"], key: "s" }} onSubmit={submit} />
      <Action title="从窗口取点…（⌘⇧P）" icon={Icon.TextCursor} shortcut={{ modifiers: ["cmd", "shift"], key: "p" }} onAction={pickPoint} />
      <Action title="从当前激活应用获取 App ID（⌘⇧D）" icon={Icon.AppWindow} shortcut={{ modifiers: ["cmd", "shift"], key: "d" }} onAction={detectApplication} />
    </ActionPanel>}>
    <Form.Description title="Safety boundary" text={warning} />
    {error && <Form.Description title="Result" text={error} />}
    {binding ? <Form.Description title="ID (immutable)" text={binding.id} /> : <Form.TextField id="id" title="ID" placeholder="toggle-sidebar" />}
    <Form.TextField id="name" title="Name" defaultValue={binding?.name} />
    <Form.TextField id="bundleId" title="App Bundle ID" placeholder="自动从激活应用获取，也可手动修改" value={bundleId} onChange={value => { generation.current++; setDetecting(false); setBundleId(value); setAppInfo("手动指定的应用标识；可从操作菜单重新获取。"); }} />
    <Form.Description title="目标应用" text={appInfo} />
    <Form.Description title="快捷键" text={shortcut ? formatShortcut(shortcut) : "尚未设置"} />
    {shortcutError && <Form.Description title="快捷键提示" text={shortcutError} />}
    <Form.Description text="点击底部「设置快捷键」或按 ⌘⇧R → 按下组合键（可重录）→ Enter 确认 / Esc 取消。此处仅展示确认结果。最后按 ⌘S 保存规则。" />
    <Form.Dropdown id="anchor" title="Anchor" value={anchor} onChange={value => setAnchor(value as Anchor)}>{anchors.map(a => <Form.Dropdown.Item key={a} value={a} title={a} />)}</Form.Dropdown>
    <Form.TextField id="x" title="Offset X" value={x} onChange={setX} />
    <Form.TextField id="y" title="Offset Y" value={y} onChange={setY} />
    <Form.Checkbox id="enabled" label="Enabled definition (execution remains disabled)" defaultValue={binding?.enabled ?? true} />
    <Form.Description text="快捷键：⌘⇧P 从窗口取点（点击或 Enter 确认 / Esc 取消 / 方向键微调，Shift=10），⌘⇧D 从当前激活应用获取 App ID（按钮在底部操作栏）。取点只打开诊断覆盖层：从不点击、不移动光标、不自动保存。Fixed: frontmost app · focused window · left button · restore cursor。" />
  </Form>;
}
