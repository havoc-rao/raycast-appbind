import { Action, ActionPanel, Alert, Icon, List, confirmAlert } from "@raycast/api";
import { useEffect, useState } from "react";
import { Binding, Config } from "./config";
import { BindingForm, Diagnostic, failure, message, store } from "./ui";
export default function ManageBindings() {
  const [config, setConfig] = useState<Config>(); const [error, setError] = useState<string>(); const [loading, setLoading] = useState(true);
  async function load() { setLoading(true); try { setConfig(await store.read()); setError(undefined); } catch (e) { setConfig(undefined); setError(message(e)); } finally { setLoading(false); } }
  useEffect(() => { void load(); }, []);
  async function change(binding: Binding, remove: boolean) {
    if (remove && !await confirmAlert({ title: `Delete ${binding.name}?`, message: "Permanently removes this binding definition.", primaryAction: { title: "Delete", style: Alert.ActionStyle.Destructive } })) return;
    try {
      setConfig(await store.update(current => {
        if (JSON.stringify(current.bindings.find(b => b.id === binding.id)) !== JSON.stringify(binding)) throw new Error("Binding changed; refresh before modifying");
        return { ...current, bindings: remove ? current.bindings.filter(b => b.id !== binding.id) : current.bindings.map(b => b.id === binding.id ? { ...b, enabled: !b.enabled } : b) };
      }));
    } catch (e) { await failure(e); }
  }
  const common = <><Action.Push title="Create Binding" icon={Icon.Plus} target={<BindingForm saved={setConfig} />} /><Action title="Reload Configuration" icon={Icon.ArrowClockwise} onAction={load} /><Action.Push title="Helper Status" target={<Diagnostic request={{ protocolVersion: 1, command: "status" }} />} /></>;
  return <List isLoading={loading} searchBarPlaceholder="Search binding name or app — no hotkeys registered" actions={<ActionPanel>{common}</ActionPanel>}>
    {error ? <List.EmptyView title="Configuration unavailable — not reset" description={error} /> : !config?.bindings.length ? <List.EmptyView title="No binding definitions" description="Create a binding. Actual clicks and app-scoped hotkeys are disabled." /> : <List.Section title="Definitions only — execution disabled" subtitle="Dry-run may reject Raycast as frontmost">
      {config.bindings.map(b => <List.Item key={b.id} title={b.name} subtitle={b.application.bundleId} keywords={[b.id, b.trigger.key]} icon={b.enabled ? Icon.CheckCircle : Icon.Circle} accessories={[{ text: [...b.trigger.modifiers, b.trigger.key].join("+") }, { text: b.enabled ? "Enabled" : "Disabled" }]} actions={<ActionPanel>
        <Action.Push title="Edit Binding" target={<BindingForm binding={b} saved={setConfig} />} />
        <Action title={b.enabled ? "Disable Binding" : "Enable Binding"} onAction={() => change(b, false)} />
        <Action.Push title="Diagnostic Dry-Run (No Click)" target={<Diagnostic request={{ protocolVersion: 1, command: "dry-run", config, bindingId: b.id }} />} />
        <Action title="Delete Binding" style={Action.Style.Destructive} onAction={() => change(b, true)} />{common}
      </ActionPanel>} />)}
    </List.Section>}
  </List>;
}
