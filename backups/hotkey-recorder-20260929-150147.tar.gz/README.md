# AppBind

为每个 App 绑定你的操作。Raycast 管规则，Swift Helper 负责原生诊断；最终目标是常驻 Helper 实现应用作用域热键及窗口相对单击。

**当前仅 P0/P1 基础诊断切片，不是完整产品。真实点击固定拒绝；没有全局热键、后台服务或登录项。** dry-run 只算坐标，不验证点击安全，不移动光标。没有自动申请系统权限。

## 设计与工程契约

- [实施计划与实际状态](<docs/plan.md>)
- [v1 配置/协议/错误码及安全契约](<docs/CONTRACT.md>)
- [完整示例配置](<examples/config.v1.json>)（示例 Bundle ID 必须改成自己的目标 App）

## 环境

开发机：macOS 26.6.2 arm64，Swift 6.4，Node.js 22.22.0 / npm 10.9.4。Swift 部署目标 macOS 13；尚未在 macOS 13 或 Intel 运行验证。需要 Xcode Command Line Tools，Raycast UI 验收需要安装 Raycast。

## Swift Helper

在工作区根目录执行：

```sh
cd helper
mkdir -p .cache/clang .cache/swiftpm
CLANG_MODULE_CACHE_PATH="$PWD/.cache/clang" SWIFTPM_MODULECACHE_OVERRIDE="$PWD/.cache/clang" swift build --disable-sandbox --cache-path "$PWD/.cache/swiftpm"
CLANG_MODULE_CACHE_PATH="$PWD/.cache/clang" SWIFTPM_MODULECACHE_OVERRIDE="$PWD/.cache/clang" swift test --disable-sandbox --cache-path "$PWD/.cache/swiftpm"
printf '%s\n' '{"protocolVersion":1,"command":"status"}' | .build/debug/appbind-helper
printf '%s\n' '{"protocolVersion":1,"command":"inspect"}' | .build/debug/appbind-helper
```

status 不提示授权，只报告权限和禁用的执行能力。inspect 查询前台 App 的聚焦 AX 窗口；缺少权限时结构化返回 PERMISSION_DENIED，不自行弹授权框。Helper 不输出窗口标题。

从根目录生成结构化 dry-run 请求（只有诊断、没有点击）：

```sh
node -e 'const fs=require("node:fs"); console.log(JSON.stringify({protocolVersion:1,command:"dry-run",config:JSON.parse(fs.readFileSync("examples/config.v1.json","utf8")),bindingId:"toggle-sidebar"}))' | helper/.build/debug/appbind-helper
```

示例使用占位 Bundle ID，通常返回 APP_MISMATCH 或权限错误；这是预期的安全拒绝，不是成功命中。CLI 使用 stdin JSON，不接受任意 shell 内容。未知命令、未知字段、未知版本、坏配置与窗口外/屏幕外坐标均拒绝。

execute 入口当前固定返回 SAFETY_NOT_IMPLEMENTED（前置请求或配置错误优先返回），不会调用发鼠标事件的 API。即使授予 AX 权限也不会开启点击。

## Raycast 扩展

在扩展目录运行：

```sh
cd raycast
npm ci --ignore-scripts --cache .npm-cache
npm run typecheck
npm test
npm run build
# 下列命令会尝试安装/链接到用户 Raycast 扩展目录；只由用户主动运行：
npm run dev
```

本地编译使用官方 Raycast CLI 的显式 `-e dist -o dist`，只写工作区构建目录，不自动导入扩展。依赖锁定：`@raycast/api 1.104.5`、`React 19.0.0`、`TypeScript 5.9.3`，已按实际安装类型核验 UI API；开发依赖和锁文件位于 [扩展清单](<raycast/package.json>) 与 [依赖锁](<raycast/package-lock.json>)。清单作者/许可证是本地脚手架元数据，公开发布前须由用户确认真实作者、许可和签名分发方案。

开发前在 Raycast 扩展偏好设置填写本工作区编译产物的**绝对路径**作为 Helper 路径。Raycast 客户端使用无 shell 的子进程 + stdin JSON，超时/过大输出/坏协议都按错误处理。扩展的具体入口、依赖版本和构建结果见下方验证记录。

### 录制快捷键（record-shortcut）

创建/编辑表单只展示当前快捷键，不再混用文本编辑和录制。点击固定底部主操作“**设置快捷键**”或按 **⌘⇧R** 打开原生录制弹窗：按下组合键时实时预览，可直接按另一组键重录；按 **Enter / 确认** 才回填，**Esc / 取消** 放弃修改。回填前检查同 App 的已有绑定（含禁用项，排除正在编辑的自身）；冲突时保留原值并提示规则名称。最后按 **⌘S** 保存规则，保存时仍校验最新配置，避免并发冲突。Raycast 原生表单不能内嵌自定义按钮，因此入口使用固定底部按钮，不再随字段焦点改变。

- 仅支持 **A–Z / 0–9 + 至少一个 Control / Option / Shift / Command**，与现有配置格式一致。
- Esc、超时或离开录制窗口取消，原快捷键不变；无效按键不会写入表单。
- 只在显式打开的录制窗口内接收键盘事件，不启用全局监听、不请求辅助功能权限、不注册快捷键、不执行绑定。macOS 保留快捷键可能被系统优先处理。
- 实际按键接收、输入法/键盘布局以及 Raycast 回填仍需人工验收。

### 从窗口取点（capture）

创建/编辑绑定时，操作菜单的“**从窗口取点…**”会关闭 Raycast 面板并显示 Helper 遮罩：目标窗口区域留亮描边、其余屏幕变暗，准星与实时锚点/偏移读数跟随指针；**点击 / Enter 确认 · Esc 取消 · 方向键微调（Shift = 10）**，120 秒无操作自动取消。确认后锚点与偏移自动回填表单，仍由你显式保存。

- 取点**不向目标应用发送点击、不移动真实光标、不激活其他应用**；左键点击遮罩在松开时确认当前准星位置（含方向键微调），与 Enter 共用确认逻辑；按下和松开均由遮罩接收，不穿透到下面的按钮。
- 前置失败关闭：Helper 无辅助功能权限返回 PERMISSION_DENIED（不弹授权框）、目标 App 未运行返回 APP_NOT_RUNNING、取点在窗口/屏幕外或偏移超界返回 UNSAFE_TARGET；取消/失败不写回表单。
- 确认瞬间重读目标窗口 AX 几何；取点身份来自表单（自动获取或手动填写），从不接受客户端提供的窗口几何。
- 遮罩键盘交互、真实权限下的焦点交接与多屏显示属于人工验收范围。

创建规则时通过 Raycast `getFrontmostApplication()` 自动获取激活应用的 Bundle ID（参考 window-panel 的前台应用查询方式），排除 Raycast 自身。先激活目标 App，再打开 Create Binding；也可通过操作菜单“从当前激活应用获取 App ID”重新获取。编辑规则保留原有 App ID，手动输入不会被尚未完成的自动查询覆盖；获取失败时显示错误并允许手动填写。不回退猜测其他应用，也不将此 App ID 视作已验证的窗口身份。新增 3 项获取逻辑单测通过，Raycast 测试累计 11/11；实际焦点行为待人工确认。规则管理仍支持手工填写 Bundle ID、锚点和偏移。快捷键字段只是保存未来服务配置，不会注册热键。配置位于 Raycast `environment.supportPath` 下，单条编辑使用锁保护的读改写和原子替换；不要同时手工修改配置。坏文件显示错误，不静默清空。进程崩溃遗留锁需先确认没有运行中的写入，再手动排障；不会自动抢锁。

Raycast 面板可能自身成为前台 App，dry-run 应安全拒绝该目标；当前不捕获进入面板前的窗口，也不靠固定延迟猜焦点。需要有效前台诊断时从外部受控入口调用 CLI，并由用户核对当前前台窗口。

**Raycast `Action.shortcut` 是面板内操作快捷键，不是全局应用作用域热键。** 为命令设置 Raycast 全局快捷键会占用非目标 App 的同一键，不能满足“未匹配 App 保留按键”。Background Refresh 也不是守护进程。

## 安全边界与未实现项

已实现的是配置/协议校验、纯几何、只读原生诊断、规则管理基础闭环与取点遮罩。尚未实现：稳定原窗口身份与跨阶段重验、修饰键释放等待、可靠遮挡/模态判定、用户真实鼠标移动检测、点击串行防重、异常 mouseUp/归位、Raycast 原窗口上下文交接、覆盖层预览、实际点击、常驻热键/IPC/登录启动。

因为上述安全链不完整，**不能通过删除一个 guard 就启用点击**。下一阶段须先为整个状态机建立测试与人工证据，才考虑 Core Graphics 事件发送。坐标使用逻辑桌面空间、X 右 Y 下；不乘 backingScaleFactor。负坐标已有纯逻辑支持，但真实多屏混合缩放仍待人工核验。

不承诺所有应用兼容，不保证按钮语义；布局变化后同一坐标可能不是同一按钮。当前版本不收集窗口标题、键入文本或截图。

## 人工验收（待执行）

1. Raycast 本地导入：创建、编辑、启停、删除规则，重开命令确认持久化；同 App 相同热键拒绝，不同 App 可复用。
2. 根据用户自愿授权，对实际 Helper 二进制路径授予 Accessibility，再运行 inspect；核对 Bundle ID、PID 与几何。授权归属与重编译后权限持久性需要实测。
3. 原生/Electron App：无窗口、最小化、模态、前台切换、Raycast 面板焦点都不得被解释为安全可点击。
4. 主屏/左侧和上方副屏、混合缩放、跨屏窗口：对照 dry-run 点和窗口逻辑坐标，检查五锚点及半开边界。
5. 取点遮罩：目标窗口描边与变暗、准星/读数跟随、Enter/Esc/方向键微调、Raycast 面板关闭后的焦点交接、取点结果回填与保存。
5. 权限撤回、Helper 路径缺失、协议版本不匹配、损坏配置、锁忙：显示准确错误，不覆盖坏配置、不点击、不抢鼠标。
6. 当前版本不得做真实点击验收；没有后台服务，退出命令即结束 Helper。无需卸载系统服务或登录项。

## 自动验证记录

根目录的跨组件验证命令（先完成 Swift 构建与 npm 依赖安装）：

```sh
node scripts/smoke-helper.mjs
./raycast/node_modules/.bin/tsx scripts/check-config-parity.ts
```

最终验证结果（2026-09-29，本机环境）：Swift 构建通过；13/13 XCTest 通过；Raycast 类型检查通过、8/8 单元测试通过、官方 CLI 本地构建通过；9/9 CLI smoke 与 25/25 跨语言配置测试通过，以上命令均退出 0。Swift 使用工作区缓存仍有用户级缓存不可写的非致命警告。SwiftPM 的 `--disable-sandbox` 仅关闭包清单的嵌套沙箱，外部工作区文件策略仍有效；本包无第三方 Swift 依赖或构建插件。

对齐测试真实捕获并修复了 Foundation JSONSerialization 去除字符串首 U+FEFF 的差异：Helper 改用保留字符串的 JSONDecoder 模型，再严格校验。中间失败及最终结果详见 [计划验证记录](<docs/plan.md>)。

脚本分别验证结构化响应与 execute 固定拒绝、两端配置规则的一致性，全部不发送输入事件。单元测试通过不代表系统权限、Raycast UI 或真实多屏已通过人工验收。

环境限制：npm 首次正常安装因 react-devtools 的 Electron 安装脚本尝试写用户缓存而被沙箱拒绝，改用 `--ignore-scripts` 只安装编译与测试所需包；React DevTools GUI 尚不可用。官方 Raycast `ray build` 初次使用默认输出目录时尝试写工作区外的用户扩展目录，被沙箱拒绝；最终使用显式工作区内输出目录的 `ray build -e dist -o dist` 完成原生 CLI 构建与类型检查。没有安装/启用扩展，本地构建成功不等同于 Raycast UI 导入验收。未请求扩大权限或另启后台服务。

